"use client";

import { ChatKitPanelMock } from "@/app/components/ChatKitPanelMock";
// import { ChatKitPanelReal } from "@/app/components/ChatKitPanelReal";

export default function Home() {
  return (
    <div className="h-screen flex flex-col bg-[#F5F5F5] overflow-hidden">
      {/* Header Fixo - RX PRO */}
      <header 
        className="flex-shrink-0 flex items-center px-8" 
        style={{ 
          backgroundColor: '#ED2025',
          height: '60px'
        }}
      >
        {/* Logo RX PRO */}
        <div className="relative" style={{ width: '50px', height: '32px' }}>
          <div className="absolute bg-white" style={{ height: '2.3px', width: '50px', top: 0 }} />
          <div className="absolute bg-white" style={{ height: '2.3px', width: '50px', bottom: 0 }} />
          <svg className="absolute" style={{ top: '5.8px', width: '50px', height: '20px' }} fill="none" viewBox="0 0 51 20">
            <g>
              <path d="M7.8992 16.0195C7.8992 17.2587 8.00933 18.4419 8.31261 19.4049H5.78009C5.50503 18.7718 5.47736 17.6162 5.47736 16.4053V12.7172C5.47736 11.3961 5.2571 10.7907 4.04618 10.7907H2.42239V19.4049H0V0.138672H4.6793C7.23895 0.138672 7.8992 0.936722 7.8992 3.71664V6.33163C7.8992 8.34114 7.54168 9.30414 6.35843 9.66165C7.54168 10.0474 7.8992 11.0104 7.8992 13.0476V16.0195ZM5.47736 4.10237C5.47736 2.80846 5.3949 2.3956 4.23877 2.3956H2.42239V8.5332H4.23877C5.36723 8.5332 5.47736 8.12033 5.47736 6.82695V4.10237Z" fill="white"/>
              <path d="M15.0501 0.138672H17.1975L14.8576 9.27646L17.3901 19.4049H14.9129L13.8946 15.139C13.5642 13.7349 13.2338 12.3591 12.9587 10.7076C12.6837 12.3591 12.3809 13.7632 12.0505 15.139L11.0045 19.4049H8.83008L11.3344 9.27646L8.96789 0.138672H11.3897L12.2708 3.63417C12.6006 4.98289 13.0141 6.68915 13.2338 7.92773C13.454 6.68915 13.8398 4.95525 14.1696 3.63417L15.0501 0.138672Z" fill="white"/>
              <path d="M23.2021 0.138672H27.716C30.2756 0.138672 30.9364 0.936722 30.9364 3.71664V8.56087C30.9364 11.3408 30.2756 12.1388 27.716 12.1388H25.6245V19.4049H23.2021V0.138672ZM27.3031 9.88193C28.4045 9.88193 28.514 9.46906 28.514 8.17569V4.10237C28.514 2.80846 28.4045 2.3956 27.3031 2.3956H25.6245V9.88193H27.3031Z" fill="white"/>
              <path d="M40.4789 16.0195C40.4789 17.2587 40.589 18.4419 40.8912 19.4049H38.3592C38.0841 18.7718 38.0565 17.6162 38.0565 16.4053V12.7172C38.0565 11.3961 37.8362 10.7907 36.6253 10.7907H35.0015V19.4049H32.5791V0.138672H37.2584C39.818 0.138672 40.4789 0.936722 40.4789 3.71664V6.33163C40.4789 8.34114 40.1208 9.30414 38.937 9.66165C40.1208 10.0474 40.4789 11.0104 40.4789 13.0476V16.0195ZM38.0565 4.10237C38.0565 2.80846 37.974 2.3956 36.8179 2.3956H35.0015V8.5332H36.8179C37.9463 8.5332 38.0565 8.12033 38.0565 6.82695V4.10237Z" fill="white"/>
              <path d="M42.4756 3.57852C42.4756 0.798065 43.1641 0 45.6955 0H47.1549C49.6869 0 50.3748 0.798065 50.3748 3.57852V15.9639C50.3748 18.7438 49.6869 19.5418 47.1549 19.5418H45.6955C43.1641 19.5418 42.4756 18.7438 42.4756 15.9639V3.57852ZM47.9529 3.96373C47.9529 2.66978 47.8428 2.25748 46.7144 2.25748H46.1366C45.0076 2.25748 44.8974 2.66978 44.8974 3.96373V15.5781C44.8974 16.8726 45.0076 17.2849 46.1366 17.2849H46.7144C47.8428 17.2849 47.9529 16.8726 47.9529 15.5781V3.96373Z" fill="white"/>
            </g>
          </svg>
        </div>
      </header>

      {/* Main Content - Container do Chat */}
      <main className="flex-1 min-h-0 overflow-hidden">
        <div className="h-full container mx-auto max-w-5xl px-6 py-8 flex items-stretch">
          <div className="flex-1 bg-white rounded-xl overflow-hidden" style={{ boxShadow: '0px 3px 3px 0px rgba(0,0,0,0.07)' }}>
            {/* --- PAINEL MOCKADO (ATIVO - PARA TESTES DE UI) --- */}
            <ChatKitPanelMock theme="light" />
            
            {/* --- PAINEL REAL (PARA OS DEVS - INTEGRAÇÃO COM AGENT BUILDER) --- */}
            {/* 
              INSTRUÇÕES PARA OS DEVS:
              1. Comente o <ChatKitPanelMock /> acima
              2. Descomente o <ChatKitPanelReal /> abaixo
              3. Configure o .env.local com:
                 - NEXT_PUBLIC_CHATKIT_WORKFLOW_ID=seu_workflow_id
                 - OPENAI_API_KEY=sua_api_key (no arquivo .env.local para o backend)
              4. Certifique-se de que o endpoint /api/create-session está funcionando
              5. IMPORTANTE: O RAG precisa retornar metadata para renderizar Citações e Previews
                 Consulte o README.md para ver o contrato de metadados esperado
            */}
            {/* <ChatKitPanelReal theme="light" /> */}
          </div>
        </div>
      </main>

      {/* Footer Fixo */}
      <footer 
        className="flex-shrink-0 py-4 flex items-center justify-center border-t"
        style={{ backgroundColor: '#F5F5F5', borderColor: 'rgba(0,0,0,0.07)' }}
      >
        <p className="text-xs text-gray-500">© 2025 RX PRO. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
}
