import { NextRequest, NextResponse } from "next/server";

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const WORKFLOW_ID = process.env.NEXT_PUBLIC_CHATKIT_WORKFLOW_ID;

// Cookie para gerenciar user_id persistente
const USER_ID_COOKIE = "chatkit_user_id";

function getUserId(request: NextRequest): string {
  const existingUserId = request.cookies.get(USER_ID_COOKIE)?.value;
  if (existingUserId) {
    return existingUserId;
  }
  return `user_${Date.now()}_${Math.random().toString(36).substring(7)}`;
}

export async function POST(request: NextRequest) {
  try {
    if (!OPENAI_API_KEY) {
      return NextResponse.json(
        { error: "OPENAI_API_KEY não configurada" },
        { status: 500 }
      );
    }

    if (!WORKFLOW_ID) {
      return NextResponse.json(
        { error: "NEXT_PUBLIC_CHATKIT_WORKFLOW_ID não configurado" },
        { status: 500 }
      );
    }

    const userId = getUserId(request);
    const body = await request.json();

    console.log("📝 Criando sessão ChatKit:", {
      userId,
      workflowId: WORKFLOW_ID,
      body,
    });

    const response = await fetch("https://api.openai.com/v1/chatkit/sessions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        ...body,
        user_id: userId,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("❌ Erro ao criar sessão:", data);
      return NextResponse.json(
        { error: data.error?.message || "Falha ao criar sessão" },
        { status: response.status }
      );
    }

    console.log("✅ Sessão criada com sucesso:", {
      userId,
      expiresAfter: data.expires_after,
    });

    // Retorna resposta com cookie
    const nextResponse = NextResponse.json(data);
    nextResponse.cookies.set(USER_ID_COOKIE, userId, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 30, // 30 dias
    });

    return nextResponse;
  } catch (error) {
    console.error("❌ Erro no endpoint create-session:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
