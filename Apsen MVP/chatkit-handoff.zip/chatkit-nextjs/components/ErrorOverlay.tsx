type ErrorOverlayProps = {
  error: string | null;
  fallbackMessage: string | null;
  onRetry: (() => void) | null;
  retryLabel?: string;
};

export function ErrorOverlay({
  error,
  fallbackMessage,
  onRetry,
  retryLabel = "Tentar novamente",
}: ErrorOverlayProps) {
  const message = error || fallbackMessage;

  if (!message) {
    return null;
  }

  const isError = Boolean(error);

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-[#F9FAFB]/95 backdrop-blur-sm">
      <div className="max-w-md p-6 bg-white rounded-xl shadow-lg">
        {isError ? (
          <>
            <div className="flex items-center gap-3 mb-4">
              <div className="flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <svg
                  className="w-6 h-6 text-red-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                  />
                </svg>
              </div>
              <h2 className="text-xl font-bold text-red-600">Erro de Configuração</h2>
            </div>
            <p className="text-gray-700 mb-6 whitespace-pre-wrap">{message}</p>
            {onRetry && (
              <button
                onClick={onRetry}
                className="w-full px-4 py-2 bg-[#ED2025] text-white rounded-lg font-medium hover:bg-[#C91D21] transition-colors"
              >
                {retryLabel}
              </button>
            )}
          </>
        ) : (
          <>
            <div className="flex items-center justify-center mb-4">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#ED2025] border-r-transparent"></div>
            </div>
            <p className="text-center text-gray-600">{message}</p>
          </>
        )}
      </div>
    </div>
  );
}
